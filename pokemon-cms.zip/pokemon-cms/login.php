<?php
require 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$email = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);

    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user'] = $user;
        header("Location: index.php");
        exit;
    } else {
        $error = "Invalid login.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-container">
<h2>Login</h2>
<?php if ($error): ?>
    <p style="color:red;"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>
<?php if (!isset($_SESSION['user'])): ?>
<form method="POST">
    <input type="text" name="username" placeholder="Username" required><br>
    <input name="email" type="email" placeholder="email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Login</button>
</form>
<?php else: ?>
    <p>
        Welcome, <?= htmlspecialchars($_SESSION['user']['username']) ?>!
    </p>
    <a href="logout.php">
        <button>Logout</button>
    </a>
    <?php if ($_SESSION['user']['role'] === 'admin'): ?>
        <a href="admin.php">
            <button>Admin Panel</button>
        </a>
    <?php endif; ?>
<?php endif; ?>
<a href="register.php">Create account</a>
</div>
</body>
</html>